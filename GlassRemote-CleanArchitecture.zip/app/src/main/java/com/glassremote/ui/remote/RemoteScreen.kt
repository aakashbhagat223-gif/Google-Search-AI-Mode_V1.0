package com.glassremote.ui.remote

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RemoteScreen(viewModel: RemoteViewModel = viewModel()) {
    val controlTarget by viewModel.controlTarget.collectAsState()
    val clipboardText by viewModel.clipboardText.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF12141C))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0x1AFFFFFF), RoundedCornerShape(12.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            ControlTarget.values().forEach { target ->
                val selected = controlTarget == target
                Button(
                    onClick = { viewModel.setControlTarget(target) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selected) Color(0xFF4F46E5) else Color.Transparent,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(target.name.replace("_", " "))
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Button(
                onClick = { viewModel.triggerTvPower() },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
            ) {
                Text("TV Power")
            }
            Button(
                onClick = { viewModel.triggerJioPower() },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEA580C))
            ) {
                Text("Box Power")
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0x0DFFFFFF), RoundedCornerShape(16.dp))
                .border(1.dp, Color(0x1AFFFFFF), RoundedCornerShape(16.dp))
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TextField(
                value = clipboardText,
                onValueChange = { viewModel.onClipboardTextChanged(it) },
                placeholder = { Text("Type text to send...", color = Color.Gray) },
                modifier = Modifier.weight(1f),
                colors = TextFieldDefaults.textFieldColors(
                    containerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                )
            )
            Button(
                onClick = { viewModel.sendClipboardText() },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4F46E5))
            ) {
                Text("Paste & Send")
            }
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(vertical = 24.dp)
        ) {
            Button(onClick = { viewModel.handleKeyEvent(19) }) { Text("▲") }
            Row(horizontalArrangement = Arrangement.spacedBy(32.dp)) {
                Button(onClick = { viewModel.handleKeyEvent(21) }) { Text("◀") }
                Button(onClick = { viewModel.handleKeyEvent(23) }) { Text("OK") }
                Button(onClick = { viewModel.handleKeyEvent(22) }) { Text("▶") }
            }
            Button(onClick = { viewModel.handleKeyEvent(20) }) { Text("▼") }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Button(onClick = { viewModel.handleKeyEvent(4) }) { Text("Back") }
            Button(onClick = { viewModel.handleKeyEvent(3) }) { Text("Home") }
            Button(onClick = { viewModel.handleKeyEvent(164) }) { Text("Mute") }
        }
    }
}
