package com.glassremote.ui.remote

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.glassremote.data.adb.Adb
import com.glassremote.data.macro.Macros
import com.glassremote.data.repository.SettingsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

enum class ControlTarget { XIAOMI_TV, JIO_BOX }

class RemoteViewModel(application: Application) : AndroidViewModel(application) {
    private val settingsRepository = SettingsRepository(application)

    private val _controlTarget = MutableStateFlow(ControlTarget.XIAOMI_TV)
    val controlTarget: StateFlow<ControlTarget> = _controlTarget.asStateFlow()

    private val _clipboardText = MutableStateFlow("")
    val clipboardText: StateFlow<String> = _clipboardText.asStateFlow()

    fun setControlTarget(target: ControlTarget) {
        _controlTarget.value = target
        if (target == ControlTarget.JIO_BOX) {
            viewModelScope.launch {
                if (settingsRepository.autoSourceSwitch.first()) {
                    Macros.executeWatchJioPipeline()
                }
            }
        }
    }

    fun onClipboardTextChanged(text: String) {
        _clipboardText.value = text
    }

    fun sendClipboardText() {
        val textToSend = _clipboardText.value
        if (textToSend.isNotBlank()) {
            viewModelScope.launch {
                Adb.injectText(textToSend)
                _clipboardText.value = ""
            }
        }
    }

    fun handleKeyEvent(keyCode: Int) {
        viewModelScope.launch {
            Adb.injectGlobalAdbKey(keyCode)
        }
    }

    fun triggerTvPower() {
        viewModelScope.launch { Adb.injectGlobalAdbKey(26) }
    }

    fun triggerJioPower() {
        viewModelScope.launch {
            Adb.injectGlobalAdbKey(223)
        }
    }
}
