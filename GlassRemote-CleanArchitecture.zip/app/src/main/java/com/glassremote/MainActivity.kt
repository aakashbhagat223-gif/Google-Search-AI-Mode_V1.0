package com.glassremote

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.TelephonyManager
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.glassremote.data.adb.Adb
import com.glassremote.data.bluetooth.BluetoothHidController
import com.glassremote.data.repository.SettingsRepository
import com.glassremote.ui.remote.RemoteScreen
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var legacyBluetoothController: BluetoothHidController
    private var callStateReceiver: BroadcastReceiver? = null
    private val mainScope = CoroutineScope(Dispatchers.Main)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        legacyBluetoothController = BluetoothHidController(this)
        legacyBluetoothController.clearLegacyState()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) 
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_PHONE_STATE), 101)
        } else {
            registerCallStatePipeline()
        }

        setContent {
            RemoteScreen()
        }
    }

    private fun registerCallStatePipeline() {
        val settingsRepository = SettingsRepository(applicationContext)
        callStateReceiver = object : BroadcastReceiver() {
            private var extendedMuteApplied = false

            override fun onReceive(context: Context?, intent: Intent?) {
                if (intent?.action == TelephonyManager.ACTION_PHONE_STATE_CHANGED) {
                    val stateString = intent.getStringExtra(TelephonyManager.EXTRA_STATE)
                    mainScope.launch {
                        if (!settingsRepository.muteOnIncomingCall.first()) return@launch

                        when (stateString) {
                            TelephonyManager.EXTRA_STATE_RINGING -> {
                                if (!extendedMuteApplied) {
                                    Adb.injectGlobalAdbKey(164)
                                    extendedMuteApplied = true
                                    Log.d("TelephonyMonitor", "Incoming phone call detected: TV muted.")
                                }
                            }
                            TelephonyManager.EXTRA_STATE_IDLE -> {
                                if (extendedMuteApplied) {
                                    Adb.injectGlobalAdbKey(164)
                                    extendedMuteApplied = false
                                    Log.d("TelephonyMonitor", "Call ended: TV audio state toggle restored.")
                                }
                            }
                        }
                    }
                }
            }
        }
        registerReceiver(callStateReceiver, IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED))
    }

    override fun onDestroy() {
        super.onDestroy()
        callStateReceiver?.let { unregisterReceiver(it) }
    }
}
