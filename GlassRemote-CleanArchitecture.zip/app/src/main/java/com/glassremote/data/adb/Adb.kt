package com.glassremote.data.adb

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.Socket

object Adb {
    private const val HOST_IP = "192.168.31.116"
    private const val ADB_PORT = 5555
    private const val TAG = "AdbEngine"

    suspend fun injectGlobalAdbKey(keyCode: Int): Result<String> = executeShellCommand("input keyevent $keyCode")

    suspend fun injectText(content: String): Result<String> = withContext(Dispatchers.IO) {
        val sanitized = content.replace(" ", "%s")
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("`", "\\`")
            .replace("$", "\\$")
        executeShellCommand("input text \"$sanitized\"")
    }

    suspend fun executeShellCommand(command: String): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(HOST_IP, ADB_PORT), 3000)
                socket.getOutputStream().use { outputStream ->
                    outputStream.write("shell:$command\n".toByteArray(Charsets.UTF_8))
                    outputStream.flush()
                    
                    BufferedReader(InputStreamReader(socket.getInputStream(), Charsets.UTF_8)).use { reader ->
                        val response = reader.readText()
                        Log.d(TAG, "CMD: [$command] -> RESP: [$response]")
                        response
                    }
                }
            }
        }.onFailure { error ->
            Log.e(TAG, "ADB communication failure on $HOST_IP:$ADB_PORT", error)
        }
    }
}
