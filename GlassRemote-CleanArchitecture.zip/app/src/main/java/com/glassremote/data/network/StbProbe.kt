package com.glassremote.data.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket

class StbProbe {
    suspend fun isTargetAccessible(ipAddress: String, port: Int, timeoutMs: Int = 1500): Boolean = 
        withContext(Dispatchers.IO) {
            runCatching {
                Socket().use { socket ->
                    socket.connect(InetSocketAddress(ipAddress, port), timeoutMs)
                    true
                }
            }.getOrDefault(false)
        }
}
