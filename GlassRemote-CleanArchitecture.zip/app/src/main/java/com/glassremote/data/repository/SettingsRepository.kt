package com.glassremote.data.repository

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "glass_settings")

class SettingsRepository(private val context: Context) {
    companion object {
        val MUTE_ON_CALL = booleanPreferencesKey("mute_on_incoming_call")
        val AUTO_SOURCE_SWITCH = booleanPreferencesKey("auto_source_switch_hdmi")
    }

    val muteOnIncomingCall: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[MUTE_ON_CALL] ?: false
    }

    val autoSourceSwitch: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[AUTO_SOURCE_SWITCH] ?: false
    }

    suspend fun setMuteOnIncomingCall(enabled: Boolean) {
        context.dataStore.edit { prefs -> prefs[MUTE_ON_CALL] = enabled }
    }

    suspend fun setAutoSourceSwitch(enabled: Boolean) {
        context.dataStore.edit { prefs -> prefs[AUTO_SOURCE_SWITCH] = enabled }
    }
}
