package com.glassremote.data.bluetooth

import android.content.Context
import android.util.Log

class BluetoothHidController(private val context: Context) {
    init {
        Log.d("BluetoothHid", "Native Bluetooth HID Subsystem disabled by architecture pivot.")
    }
    fun clearLegacyState() {
        // No-op placeholder for clean decoupling
    }
}
