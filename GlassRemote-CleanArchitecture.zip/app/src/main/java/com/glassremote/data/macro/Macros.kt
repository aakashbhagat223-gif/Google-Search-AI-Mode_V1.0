package com.glassremote.data.macro

import com.glassremote.data.adb.Adb
import kotlinx.coroutines.delay

object Macros {
    suspend fun executeWatchJioPipeline(): Result<String> {
        Adb.injectGlobalAdbKey(224)
        delay(800)
        val hdmiIntentCommand = "am start -a android.intent.action.VIEW -d content://android.media.tv/passthrough/com.mediatek.tis%2F.HdmiInputService%2FHW3"
        return Adb.executeShellCommand(hdmiIntentCommand)
    }
}
